"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  Car,
  Plus,
  Edit,
  Trash2,
  Save,
  X,
  Upload,
  Eye,
  ArrowLeft,
} from "lucide-react";
import Link from "next/link";

interface CarData {
  id: number;
  title: string;
  price: number;
  year: number;
  mileage: number;
  fuel: string;
  transmission: string;
  power: string;
  displacement: string;
  color: string;
  doors: number;
  seats: number;
  images: string[];
  features: string[];
  description: string;
  condition: string;
  warranty: string;
  financing: string;
  previousOwners: number;
  accidentFree: boolean;
  nonsmoker: boolean;
}

export default function AdminPage() {
  const [cars, setCars] = useState<CarData[]>([
    {
      id: 1,
      title: "BMW 3er 320d Touring",
      price: 18900,
      year: 2018,
      mileage: 85000,
      fuel: "Diesel",
      transmission: "Automatik",
      power: "190 PS",
      displacement: "2.0L",
      color: "Schwarz Metallic",
      doors: 5,
      seats: 5,
      images: [
        "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=500&h=300&fit=crop",
        "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=500&h=300&fit=crop",
      ],
      features: ["Navi", "Klimaautomatik", "Xenon", "Ledersitze"],
      description: "Gepflegter BMW 3er Touring mit umfangreicher Ausstattung.",
      condition: "Sehr gut",
      warranty: "12 Monate Garantie",
      financing: "Finanzierung möglich ab 199€/Monat",
      previousOwners: 2,
      accidentFree: true,
      nonsmoker: true,
    },
  ]);

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingCar, setEditingCar] = useState<CarData | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    price: "",
    year: "",
    mileage: "",
    fuel: "",
    transmission: "",
    power: "",
    displacement: "",
    color: "",
    doors: "",
    seats: "",
    images: "",
    features: "",
    description: "",
    condition: "",
    warranty: "",
    financing: "",
    previousOwners: "",
    accidentFree: true,
    nonsmoker: true,
  });

  const resetForm = () => {
    setFormData({
      title: "",
      price: "",
      year: "",
      mileage: "",
      fuel: "",
      transmission: "",
      power: "",
      displacement: "",
      color: "",
      doors: "",
      seats: "",
      images: "",
      features: "",
      description: "",
      condition: "",
      warranty: "",
      financing: "",
      previousOwners: "",
      accidentFree: true,
      nonsmoker: true,
    });
  };

  const handleAddCar = () => {
    if (!formData.title || !formData.price) return;

    const newCar: CarData = {
      id: Math.max(...cars.map((c) => c.id), 0) + 1,
      title: formData.title,
      price: parseInt(formData.price),
      year: parseInt(formData.year) || 2020,
      mileage: parseInt(formData.mileage) || 0,
      fuel: formData.fuel || "Benzin",
      transmission: formData.transmission || "Manuell",
      power: formData.power || "150 PS",
      displacement: formData.displacement || "2.0L",
      color: formData.color || "Schwarz",
      doors: parseInt(formData.doors) || 5,
      seats: parseInt(formData.seats) || 5,
      images: formData.images
        .split(",")
        .map((img) => img.trim())
        .filter((img) => img) || [
        "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=500&h=300&fit=crop",
      ],
      features: formData.features
        .split(",")
        .map((f) => f.trim())
        .filter((f) => f),
      description: formData.description,
      condition: formData.condition || "Gut",
      warranty: formData.warranty || "12 Monate Garantie",
      financing: formData.financing || "Finanzierung verfügbar",
      previousOwners: parseInt(formData.previousOwners) || 1,
      accidentFree: formData.accidentFree,
      nonsmoker: formData.nonsmoker,
    };

    setCars([...cars, newCar]);
    resetForm();
    setIsAddDialogOpen(false);
  };

  const handleEditCar = (car: CarData) => {
    setEditingCar(car);
    setFormData({
      title: car.title,
      price: car.price.toString(),
      year: car.year.toString(),
      mileage: car.mileage.toString(),
      fuel: car.fuel,
      transmission: car.transmission,
      power: car.power,
      displacement: car.displacement,
      color: car.color,
      doors: car.doors.toString(),
      seats: car.seats.toString(),
      images: car.images.join(", "),
      features: car.features.join(", "),
      description: car.description,
      condition: car.condition,
      warranty: car.warranty,
      financing: car.financing,
      previousOwners: car.previousOwners.toString(),
      accidentFree: car.accidentFree,
      nonsmoker: car.nonsmoker,
    });
  };

  const handleUpdateCar = () => {
    if (!editingCar || !formData.title || !formData.price) return;

    const updatedCar: CarData = {
      ...editingCar,
      title: formData.title,
      price: parseInt(formData.price),
      year: parseInt(formData.year),
      mileage: parseInt(formData.mileage),
      fuel: formData.fuel,
      transmission: formData.transmission,
      power: formData.power,
      displacement: formData.displacement,
      color: formData.color,
      doors: parseInt(formData.doors),
      seats: parseInt(formData.seats),
      images: formData.images
        .split(",")
        .map((img) => img.trim())
        .filter((img) => img),
      features: formData.features
        .split(",")
        .map((f) => f.trim())
        .filter((f) => f),
      description: formData.description,
      condition: formData.condition,
      warranty: formData.warranty,
      financing: formData.financing,
      previousOwners: parseInt(formData.previousOwners),
      accidentFree: formData.accidentFree,
      nonsmoker: formData.nonsmoker,
    };

    setCars(cars.map((car) => (car.id === editingCar.id ? updatedCar : car)));
    setEditingCar(null);
    resetForm();
  };

  const handleDeleteCar = (id: number) => {
    setCars(cars.filter((car) => car.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Car className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">
                Auto Service 19 - Admin
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/cars">
                <Button variant="ghost" size="sm">
                  <Eye className="h-4 w-4 mr-2" />
                  Autohandel ansehen
                </Button>
              </Link>
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Zur Hauptseite
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Fahrzeug-Verwaltung
            </h1>
            <p className="text-gray-600 mt-2">
              Verwalten Sie die verfügbaren Fahrzeuge
            </p>
          </div>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Neues Fahrzeug
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Neues Fahrzeug hinzufügen</DialogTitle>
                <DialogDescription>
                  Geben Sie die Details des neuen Fahrzeugs ein.
                </DialogDescription>
              </DialogHeader>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Fahrzeug Titel *</Label>
                  <input
                    id="title"
                    value={formData.title}
                    onChange={(e: { target: { value: any } }) =>
                      setFormData({ ...formData, title: e.target.value })
                    }
                    placeholder="z.B. BMW 3er 320d Touring"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price">Preis (€) *</Label>
                  <input
                    id="price"
                    type="number"
                    value={formData.price}
                    onChange={(e: { target: { value: any } }) =>
                      setFormData({ ...formData, price: e.target.value })
                    }
                    placeholder="18900"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="year">Baujahr</Label>
                  <input
                    id="year"
                    type="number"
                    value={formData.year}
                    onChange={(e: { target: { value: any } }) =>
                      setFormData({ ...formData, year: e.target.value })
                    }
                    placeholder="2018"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mileage">Kilometerstand</Label>
                  <input
                    id="mileage"
                    type="number"
                    value={formData.mileage}
                    onChange={(e: { target: { value: any } }) =>
                      setFormData({ ...formData, mileage: e.target.value })
                    }
                    placeholder="85000"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fuel">Kraftstoff</Label>
                  <Select
                    value={formData.fuel}
                    onValueChange={(value) =>
                      setFormData({ ...formData, fuel: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Kraftstoff wählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Benzin">Benzin</SelectItem>
                      <SelectItem value="Diesel">Diesel</SelectItem>
                      <SelectItem value="Elektro">Elektro</SelectItem>
                      <SelectItem value="Hybrid">Hybrid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="transmission">Getriebe</Label>
                  <Select
                    value={formData.transmission}
                    onValueChange={(value) =>
                      setFormData({ ...formData, transmission: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Getriebe wählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Manuell">Manuell</SelectItem>
                      <SelectItem value="Automatik">Automatik</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="power">Leistung</Label>
                  <input
                    id="power"
                    value={formData.power}
                    onChange={(e: { target: { value: any } }) =>
                      setFormData({ ...formData, power: e.target.value })
                    }
                    placeholder="190 PS"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="color">Farbe</Label>
                  <input
                    id="color"
                    value={formData.color}
                    onChange={(e: { target: { value: any } }) =>
                      setFormData({ ...formData, color: e.target.value })
                    }
                    placeholder="Schwarz Metallic"
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="images">Bild URLs (kommagetrennt)</Label>
                  <Textarea
                    id="images"
                    value={formData.images}
                    onChange={(e) =>
                      setFormData({ ...formData, images: e.target.value })
                    }
                    placeholder="https://example.com/car1.jpg, https://example.com/car2.jpg"
                    rows={3}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="features">Ausstattung (kommagetrennt)</Label>
                  <input
                    id="features"
                    value={formData.features}
                    onChange={(e: { target: { value: any } }) =>
                      setFormData({ ...formData, features: e.target.value })
                    }
                    placeholder="Navi, Klimaautomatik, Xenon, Ledersitze"
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="description">Beschreibung</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    placeholder="Beschreibung des Fahrzeugs..."
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAddDialogOpen(false);
                    resetForm();
                  }}
                >
                  Abbrechen
                </Button>
                <Button onClick={handleAddCar}>
                  <Save className="h-4 w-4 mr-2" />
                  Speichern
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Cars List */}
        <div className="space-y-4">
          {cars.map((car) => (
            <Card key={car.id}>
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-6">
                  <img
                    src={
                      car.images[0] ||
                      "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=500&h=300&fit=crop"
                    }
                    alt={car.title}
                    className="w-full lg:w-48 h-32 object-cover rounded-lg"
                  />

                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-gray-900">
                          {car.title}
                        </h3>
                        <p className="text-2xl font-bold text-blue-600">
                          {car.price.toLocaleString("de-DE")} €
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditCar(car)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteCar(car.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-4">
                      <div>Jahr: {car.year}</div>
                      <div>KM: {car.mileage.toLocaleString("de-DE")}</div>
                      <div>Kraftstoff: {car.fuel}</div>
                      <div>Getriebe: {car.transmission}</div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {car.features.map((feature, index) => (
                        <Badge key={index} variant="secondary">
                          {feature}
                        </Badge>
                      ))}
                    </div>

                    {car.description && (
                      <p className="text-gray-600 text-sm">{car.description}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {cars.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <Car className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Noch keine Fahrzeuge vorhanden
              </h3>
              <p className="text-gray-600 mb-4">
                Fügen Sie Ihr erstes Fahrzeug hinzu, um zu beginnen.
              </p>
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Erstes Fahrzeug hinzufügen
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Edit Dialog */}
      {editingCar && (
        <Dialog
          open={!!editingCar}
          onOpenChange={() => {
            setEditingCar(null);
            resetForm();
          }}
        >
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Fahrzeug bearbeiten</DialogTitle>
              <DialogDescription>
                Bearbeiten Sie die Details des Fahrzeugs.
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-title">Fahrzeug Titel *</Label>
                <input
                  id="edit-title"
                  value={formData.title}
                  onChange={(e: { target: { value: any } }) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-price">Preis (€) *</Label>
                <input
                  id="edit-price"
                  type="number"
                  value={formData.price}
                  onChange={(e: { target: { value: any } }) =>
                    setFormData({ ...formData, price: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-year">Baujahr</Label>
                <input
                  id="edit-year"
                  type="number"
                  value={formData.year}
                  onChange={(e: { target: { value: any } }) =>
                    setFormData({ ...formData, year: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-mileage">Kilometerstand</Label>
                <input
                  id="edit-mileage"
                  type="number"
                  value={formData.mileage}
                  onChange={(e: { target: { value: any } }) =>
                    setFormData({ ...formData, mileage: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-fuel">Kraftstoff</Label>
                <Select
                  value={formData.fuel}
                  onValueChange={(value) =>
                    setFormData({ ...formData, fuel: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Benzin">Benzin</SelectItem>
                    <SelectItem value="Diesel">Diesel</SelectItem>
                    <SelectItem value="Elektro">Elektro</SelectItem>
                    <SelectItem value="Hybrid">Hybrid</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-transmission">Getriebe</Label>
                <Select
                  value={formData.transmission}
                  onValueChange={(value) =>
                    setFormData({ ...formData, transmission: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Manuell">Manuell</SelectItem>
                    <SelectItem value="Automatik">Automatik</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-power">Leistung</Label>
                <input
                  id="edit-power"
                  value={formData.power}
                  onChange={(e: { target: { value: any } }) =>
                    setFormData({ ...formData, power: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-color">Farbe</Label>
                <input
                  id="edit-color"
                  value={formData.color}
                  onChange={(e: { target: { value: any } }) =>
                    setFormData({ ...formData, color: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="edit-images">Bild URLs (kommagetrennt)</Label>
                <Textarea
                  id="edit-images"
                  value={formData.images}
                  onChange={(e) =>
                    setFormData({ ...formData, images: e.target.value })
                  }
                  rows={3}
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="edit-features">
                  Ausstattung (kommagetrennt)
                </Label>
                <input
                  id="edit-features"
                  value={formData.features}
                  onChange={(e: { target: { value: any } }) =>
                    setFormData({ ...formData, features: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="edit-description">Beschreibung</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                />
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-4">
              <Button
                variant="outline"
                onClick={() => {
                  setEditingCar(null);
                  resetForm();
                }}
              >
                Abbrechen
              </Button>
              <Button onClick={handleUpdateCar}>
                <Save className="h-4 w-4 mr-2" />
                Aktualisieren
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
